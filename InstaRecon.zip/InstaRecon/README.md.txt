# Instagram OSINT Tool

Ye tool Instagram ke public aur private profiles se photos, videos, highlights download karta hai. Saath hi profile bio se email aur phone number extract karta hai.

## Installation

1. Python 3 install karein (https://www.python.org/downloads/)
2. Terminal/Command Prompt kholen aur project folder me jaakar ye command chalayein:

```bash
pip install -r requirements.txt
Usage
Terminal/Command Prompt me project folder me jaakar ye command chalayein:

Windows
cmd

Copy
python instagram_osint.py
macOS / Linux
bash

Copy
python3 instagram_osint.py


